﻿
namespace SolidMonkeys
{
	class PluginInfo
	{
		public const string GUID = "com.ahauntedarmy.gorillatag.solidmonkeys";
		public const string Name = "SolidMonkeys";
		public const string Version = "1.0.1";
	}
}
