# Solid Monkeys
Gorilla Tag Mod that makes you able to collide and walk on other gorillas.

### Dependencies
- Utilla
- Supports Haunted Mod Menu